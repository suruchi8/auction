function send_message(){
    var name=jQuery("#name").val();
    var email=jQuery("#email").val();
    var mobile=jQuery("#mobile").val();
    var message=jQuery("#message").val();
 
    if(name==""){
    alert('Please enter name');
 }else if(email==""){
     alert('Please enter email');
 }
 else if(mobile==""){
     alert('Please enter mobile');
 }
 else if(message==""){
     alert('Please enter message');
 }else{
     jQuery.ajax({
 url: 'send_message.php',
 type:'post',
 data:'&name='+name+'&email='+email+'&mobile='+mobile+'&message='+message,
 success:function(result){
     alert(result);
     }
  });
 }
 }
 