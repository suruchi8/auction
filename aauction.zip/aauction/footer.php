
<!-- footer section starts  -->


<section class="credit">

    <p> created by <span>JSSS</span> | All rights reserved! </p>


</section>

<!-- footer section ends -->


<!-- swiper js link      -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="script.js"></script>


</body>
</html>