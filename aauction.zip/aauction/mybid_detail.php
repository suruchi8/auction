<?php
require('top.php');
$order_id=get_safe_value($con,$_GET['id']);

?>
<section class="about">
<?php
$uid=$_SESSION['user_id'];
$res=mysqli_query($con,"select distinct(order_detail.id),order_detail.*,product.name,product.image,product.starting_price,product.due_date from order_detail,product,orders where order_detail.order_id='$order_id' and orders.user_id='$uid' and product.id=order_detail.product_id");

while($row=mysqli_fetch_assoc($res)){
?>
<div class="image">
        <img src="<?php echo PRODUCT_IMAGE_SITE_PATH.$row['image']?>" alt="">
    </div>

    <div class="content">
        <h3>Name:<?php echo $row['name']?></h3>
        <br><br>
       
        <h1>Starting Bid:<?php echo $row['starting_price']?></h1>
 <br>
        <h1>Due Date:<?php echo $row['due_date']?></h1>
 
    </div>

    <?php } ?>
</section>


<?php
require('footer.php');
?>