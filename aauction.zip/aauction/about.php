<?php
require('top.php');
?>


<!-- about section starts  -->

<section class="about">

    <div class="image">
        <img src="image/illustration.jpg" alt="">
    </div>

    <div class="content">
        <h3>Main purpose</h3>
        <p>As we know arts aren't much appreciated in our country as much as other things.So we observed that the artists and their creations were greatly undervalued.</p>
        <p>in order to address this situation and to provide the artists their deserved value and recognition we created this site.</p>
       
    </div>

</section>




<?php
require('footer.php');
?>