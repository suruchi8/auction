<div class="clearfix"></div>
         <footer class="site-footer">
            <div class="footer-inner bg-white">
               <div class="row">
                  <div class="col-sm-6">
                     Copyright &copy; <?php echo date('Y')?> 
                  </div>
                  
               </div>
            </div>
         </footer>
      </div>
   </body>
</html>