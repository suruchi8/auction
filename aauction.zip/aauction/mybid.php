<?php
require('top.php');

?>
<section class="about">
    <table class="table" cellpadding="27" cellspacing="25">
<tr>
<thead>
   
    <th>order</th>
    <th>added_on</th>
    <th>bid amount</th>
    <th>address</th>
    <th>city</th>
    <th>pincode</th>
</thead>
</tr>
<?php
$uid=$_SESSION['user_id'];
$res=mysqli_query($con,"select * from orders where user_id='$uid'");

while($row=mysqli_fetch_assoc($res)){
?>
<tbody>
<tr>
<td><a href="mybid_detail.php?id=<?php echo $row['id']?>"><?php echo $row['id']?></a> </td> 

<td><?php echo $row['added_on']?></a> </td> 
<td><?php echo $row['bid_amt']?></a> </td> 
<td><?php echo $row['address']?></a> </td> 
<td><?php echo $row['city']?></a> </td> 
<td><?php echo $row['pincode']?></a> </td> 
</tr>

</tbody>
<?php } ?>
</table>
</section>
<?php
require('footer.php');
?>

